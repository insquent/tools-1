(function () {
  "use strict";

  angular.module("insequent").config(routerConfig);

  /** @ngInject */
  function routerConfig($stateProvider, $urlRouterProvider) {
    $stateProvider

      .state("signin", {
        url: "/signin",
        templateUrl: "app/components/authentication/signin/signin.html",
        controller: 'SigninController as ctrl',
        data: { pageTitle: 'Sign In' }
      })
      .state("signup", {
        url: "/signup",
        templateUrl: "app/components/authentication/signup/signup.html",
        controller: 'SignUpController as ctrl',
        data: { pageTitle: 'Sign Up' }
      })
      .state("resetpassword", {
        url: "/resetpassword",
        templateUrl: "app/components/authentication/resetpassword/resetpassword.html",
        controller: 'ResetPasswordController as ctrl',
        data: { pageTitle: 'Reset Password' }
      })
      .state("forgotpassword", {
        url: "/forgotpassword",
        templateUrl: "app/components/authentication/forgotpassword/forgotpassword.html",
        controller: 'ForgotPasswordController as ctrl',
        data: { pageTitle: 'Forgot Password' }
      })
      .state("index", {
        abstract: true,
        url: "/index",
        templateUrl: "app/components/common/content.html"
      })
      .state("index.mediaLibrary", {
        url: "/mediaLibrary",
        templateUrl: "app/components/mediaLibrary/mediaLibrary.html",
        controller: 'MediaLibraryController as ctrl',
        params: { pageTitle: 'Media Library', path: 'Home' }
      })
      .state("index.main", {
        url: "/main",
        templateUrl: "app/main/main.html",
        params: { pageTitle: "Dashboard", path: 'Home' }
      })
      .state("index.account", {
        abstract: true,
        url: "/account",
        templateUrl: "app/components/account/account-content.html"
      })
      .state("index.account.profile", {
        url: "/profile",
        templateUrl: "app/components/account/profile/profile.html",
        controller: 'ProfileController as ctrl',
        params: { path: "Home / Account", pageTitle: "Profile" }
      })
      .state("index.account.orderDetails", {
        url: "/order-details",
        templateUrl: "app/components/account/transaction/order-details.html",
        controller: 'OrderDetailsController as ctrl',
        params: { path: "Home / Account", pageTitle: "Order Details" }
      })
      .state("index.account.orderHistory", {
        url: "/order-history",
        templateUrl: "app/components/account/transaction/order-history.html",
        controller: 'OrderHistoryController as ctrl',
        params: { path: "Home / Account", pageTitle: "Order History" }
      })
      .state("index.builder", {
        abstract: true,
        url: "/builder",
        templateUrl: "app/components/toolsBuilder/builder-content.html"
      })
      .state("index.builder.calculator", {
        url: "/calculator",
        templateUrl: "app/components/toolsBuilder/calculator/calculator.html",
        controller: 'CalculatorController as ctrl',
        params: { path: "Home / Tools Builder ", pageTitle: "Calculator" }
      })
      .state("preview", {
        url: "/preview",
        templateUrl: "app/components/toolsBuilder/preview/templatePreview.html",
        controller: 'PreviewController as ctrl'
      })
      .state("index.builder.poll", {
        url: "/poll",
        templateUrl: "app/components/toolsBuilder/poll/poll.html",
        controller: 'PollController as ctrl',
        params: { path: "Home / Tools Builder ", pageTitle: "Poll" }
      })
      .state("pollPreview", {
        url: "/poll-preview",
        templateUrl: "app/components/toolsBuilder/preview/templatePollPreview.html",
        controller: 'PollPreviewController as ctrl'
      })
      .state("index.builder.quiz", {
        url: "/quiz",
        templateUrl: "app/components/toolsBuilder/quiz/quiz.html",
        controller: 'QuizController as ctrl',
        params: { path: "Home / Tools Builder ", pageTitle: "Quiz" }
      })
      .state("quizPreview", {
        url: "/quiz-preview",
        templateUrl: "app/components/toolsBuilder/preview/templateQuizPreview.html",
        controller: 'QuizPreviewController as ctrl'
      })
      .state("index.analytics", {
        url: "/analytics",
        templateUrl: "app/components/analytics/analytics.html",
        controller: 'AnalyticsController as ctrl',
        params: { path: "Home", pageTitle: "Analytics" }
      });

    $urlRouterProvider.otherwise("/signin");
  }
})();
"use strict";
/*eslint angular/di: [2,"array"]*/
angular.module("insequent").controller("MediaLibraryController", ['$sce', '$scope', '$localStorage', 'Store', '$log', '$interval', '$window', function ($sce, $scope, $localStorage, Store, $log, $interval, $window) {

  /*eslint angular/controller-as-vm: 0*/
  var ctrl = this;
  /*eslint angular/controller-as-vm: 0*/
  ctrl.FileTypeText = 'Upload File';
  ctrl.fileTypeIsActive = 'file';
  ctrl.isSuccess = false;
  ctrl.isError = false;
  ctrl.sources = [];

  $interval(function () {
    ctrl.isSuccess = false;
    ctrl.isError = false;
  }, 8000);

  ctrl.isShow = function () {
    ctrl.isSuccess = false;
    ctrl.isError = false;
  };

  ctrl.fileCountShow = function () {
    Store.fileCount($localStorage.apiToken)
      .then(function (response) {
        $log.log('======File Count=======');
        //$log.log(response);
        ctrl.fileCount = response.data.count;
      }).catch(function (error) {
        $log.log(error);
      });
  };

  ctrl.imageCountShow = function () {
    Store.imageCount($localStorage.apiToken)
      .then(function (response) {
        $log.log('======Image Count=======');
        //$log.log(response);
        ctrl.pictureCount = response.data.count;
      }).catch(function (error) {
        $log.log(error);
      });
  };

  ctrl.videoCountShow = function () {
    Store.videoCount($localStorage.apiToken)
      .then(function (response) {
        $log.log('======Video Count=======');
        //$log.log(response);
        ctrl.videoCount = response.data.count;
      }).catch(function (error) {
        $log.log(error);
      });
  };

  ctrl.getMedia = function () {
    Store.getMedia($localStorage.apiToken)
      .then(function (response) {
        $log.log('======Media files=======');
        //$log.log(response);
        ctrl.sources = [];
        for (var i = 0; i < response.data.length; i++) {
          var units = ['bytes', 'kB', 'MB', 'GB', 'TB', 'PB'];
          var number = Math.floor(Math.log(response.data[i].size) / Math.log(1024));
          var fileSize = (response.data[i].size / Math.pow(1024, Math.floor(number))).toFixed(2) + ' ' + units[number];
          //$log.log(fileSize);
          ctrl.sources.push({ id: response.data[i].id, src: response.data[i].file_path, type: response.data[i].mime_type, media: response.data[i].type, name: response.data[i].name, created: response.data[i].created_at, fileSize: fileSize });
        }
        //$log.log(ctrl.sources);
      }).catch(function (error) {
        $log.log(error);
      });
  };

  ctrl.config = {
    tracks: [
      {
        src: "http://www.videogular.com/assets/subs/pale-blue-dot.vtt",
        kind: "subtitles",
        srclang: "en",
        label: "English",
        default: ""
      }
    ],
    theme: {
      url: "https://unpkg.com/videogular@2.1.2/dist/themes/default/videogular.css"
    }
  };

  ctrl.mediaUpload = function () {
    ctrl.isError = false;
    ctrl.isSuccess = false;
    var file = $scope.myFile;

    if (file != null) {
      var extn = file.name.split(".").pop();
      if (ctrl.fileTypeIsActive === 'file') {
        if (extn === 'doc' || extn === 'docx' || extn === 'pdf') {
          Store.mediaUpload($localStorage.apiToken, file, ctrl.fileTypeIsActive)
            .then(function (response) {
              $log.log('======Upload Media=======');
              ctrl.supportedFormat = 'Your file is uploaded successfully';
              ctrl.isSuccess = true;
              ctrl.fileCountShow();
              ctrl.getMedia();
              $log.log(response);
            }).catch(function (error) {
              $log.log(error);
              ctrl.supportedFormat = 'Somthing is going wrong';
              ctrl.isError = true;
            });
        } else {
          ctrl.supportedFormat = 'Supported image format are doc/ docx/ pdf';
          ctrl.isError = true;
        }
      } else if (ctrl.fileTypeIsActive === 'image') {
        if (extn === 'png' || extn === 'jpg' || extn === 'jpeg') {
          Store.mediaUpload($localStorage.apiToken, file, ctrl.fileTypeIsActive)
            .then(function (response) {
              $log.log('======Upload Media=======');
              $log.log(response);
              ctrl.supportedFormat = 'Your file is uploaded successfully';
              ctrl.isSuccess = true;
              ctrl.imageCountShow();
              ctrl.getMedia();
            }).catch(function (error) {
              $log.log(error);
              ctrl.supportedFormat = 'Somthing is going wrong';
              ctrl.isError = true;
            });
        } else {
          ctrl.supportedFormat = 'Supported image format are jpeg/ jpg/ png';
          ctrl.isError = true;
        }
      } else {
        if (extn === 'mp4' || extn === 'wmv' || extn === 'mov') {
          if (file.size < 10485760) {
            Store.mediaUpload($localStorage.apiToken, file, ctrl.fileTypeIsActive)
              .then(function (response) {
                $log.log('======Upload Media=======');
                $log.log(response);
                ctrl.supportedFormat = 'Your file is uploaded successfully';
                ctrl.isSuccess = true;
                ctrl.videoCountShow();
                ctrl.getMedia();
              }).catch(function (error) {
                $log.log(error);
                ctrl.supportedFormat = 'Somthing is going wrong';
                ctrl.isError = true;
              });
          } else {
            ctrl.supportedFormat = 'Maximum uploaded video size is 10 MB';
            ctrl.isError = true;
          }
        } else {
          ctrl.supportedFormat = 'Supported image format are mp4/ wmv/ mov';
          ctrl.isError = true;
        }
      }
    } else {
      ctrl.supportedFormat = 'Please select a file';
      ctrl.isError = true;
    }
    angular.element("input[type='file']").val(null);
  };

  ctrl.fileType = function (fileType) {
    if (fileType === 'file') {
      ctrl.FileTypeText = 'Upload File';
      ctrl.fileTypeIsActive = 'file';
    } else if (fileType === 'image') {
      ctrl.FileTypeText = 'Upload Picture';
      ctrl.fileTypeIsActive = 'image';
    } else {
      ctrl.FileTypeText = 'Upload Video';
      ctrl.fileTypeIsActive = 'video';
    }
  };

  ctrl.deleteMedia = function (index, id, type) {
    if ($window.confirm("Are you sure ?")) {
      Store.deleteMedia($localStorage.apiToken, id)
        .then(function (response) {
          $log.log(response);
          if (type == 'file') {
            ctrl.fileCountShow();
          } else if (type == 'image') {
            ctrl.imageCountShow();
          } else {
            ctrl.videoCountShow();
          }
          ctrl.sources.splice(index, 1);
        }).catch(function (error) {
          $log.log(error);
        });
    }
  };
  ctrl.initialize = function () {
    ctrl.fileCountShow();
    ctrl.imageCountShow();
    ctrl.videoCountShow();
    ctrl.getMedia();
  };
  ctrl.initialize();
}]);

"use strict";

angular.module("insequent").controller("AnalyticsController", function ($log) {

  /*eslint angular/controller-as-vm: 0*/
  //var ctrl = this;
  /*eslint angular/controller-as-vm: 0*/
  $log.log('AnalyticsController');

});

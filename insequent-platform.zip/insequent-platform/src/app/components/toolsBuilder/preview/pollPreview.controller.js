"use strict";

angular.module("insequent").controller("PollPreviewController", function ($log) {
  /*eslint angular/controller-as-vm: 0*/
  var ctrl = this;
  /*eslint angular/controller-as-vm: 0*/
  //store user response for preview
  ctrl.user_preview_response = [];
  ctrl.currentView = 0;
  ctrl.templates = [
    {
      "isWelcomePage": true,
      "welcomeHeading": "Your Heading will appear here.",
      "welcomeSubheading": "Your Sub heading will appear here.",
      "welcomeButtonText": "GET STARTED",
      "logoPath": "",
      "pageType": 0,
      "prevPtr": null,
      "thisPtr": 0,
      "nextPtr": 1,
      "$$hashKey": "object:205"
    },
    {
      "prevPtr": 0,
      "thisPtr": 1,
      "nextPtr": 2,
      "pageType": 1,
      "questionId": 1,
      "questionTitle": "Do you want \"About Us\" page ?",
      "questionOptions": [
        {
          "caption": "Yes",
          "value": 30
        },
        {
          "caption": "No",
          "value": 10
        },
        {
          "caption": "Maybe",
          "value": 60
        }
      ],
      "selectedValue": '',
      "backgroundImage": null,
      "backgroundColor": "#fff",
      "$$hashKey": "object:206"
    },
    {
      "prevPtr": 1,
      "thisPtr": 2,
      "nextPtr": 3,
      "pageType": 1,
      "questionId": 2,
      "questionTitle": "Do you want \"Gallery\" page ?",
      "questionOptions": [
        {
          "caption": "Yes",
          "value": 90
        },
        {
          "caption": "No",
          "value": 10
        }
      ],
      "selectedValue": '',
      "backgroundImage": null,
      "backgroundColor": "#fff",
      "$$hashKey": "object:207"
    },
    {
      "prevPtr": 2,
      "thisPtr": 3,
      "nextPtr": 4,
      "pageType": 1,
      "questionId": 3,
      "questionTitle": "Do you want \"Team\" page ?",
      "questionOptions": [
        {
          "caption": "Yes",
          "value": 20
        },
        {
          "caption": "No",
          "value": 10
        }
      ],
      "selectedValue": '',
      "backgroundImage": null,
      "backgroundColor": "#fff",
      "$$hashKey": "object:208"
    },
    {
      "prevPtr": 3,
      "thisPtr": 4,
      "nextPtr": 5,
      "pageType": 1,
      "questionId": 4,
      "questionTitle": "Do you want \"Contact Us\" page ?",
      "questionOptions": [
        {
          "caption": "Yes",
          "value": 20
        },
        {
          "caption": "No",
          "value": 10
        }
      ],
      "selectedValue": '',
      "backgroundImage": null,
      "backgroundColor": "#fff",
      "$$hashKey": "object:209"
    },
    {
      "prevPtr": 4,
      "thisPtr": 5,
      "nextPtr": 6,
      "pageType": 1,
      "questionId": 5,
      "questionTitle": "Demo",
      "questionOptions": [
        {
          "caption": "Y",
          "value": 2
        }
      ],
      "selectedValue": '',
      "backgroundImage": null,
      "backgroundColor": "#fff"
    },
    {
      "heading": "Your Heading will appear here.",
      "subheading": "Your Sub heading will appear here.",
      "buttonText": "GET STARTED",
      "expression": "(Q1+Q2+Q3*2)+Q4*20",
      "pageType": 2,
      "prevPtr": 5,
      "thisPtr": 6,
      "nextPtr": null,
      "$$hashKey": "object:210"
    }
  ];

  ctrl.nextPage = function (next) {
    // $log.log('nextPage');
    // $log.log(next);

    $log.log(ctrl.currentView);
    if (next > 1) {
      var a = ctrl.findDuplicate(ctrl.user_preview_response, next - 1);
      if (!a) {
        $log.log('answer given');
        ctrl.currentView = next;
      } else {
        $log.log('answer not given');
        // ctrl.currentView = next;
      }
    } else {
      ctrl.currentView = next;
    }

  };

  ctrl.prevPage = function (prev) {
    $log.log('prevPage');
    $log.log(ctrl.currentView);
    ctrl.currentView = prev;
    $log.log(ctrl.currentView);
  };

  //Record user response for the preview
  ctrl.recordUserPreviewResponse = function (questionID, selectedValue) {
    ctrl.templates[questionID].selectedValue = selectedValue;
    if (ctrl.findDuplicate(ctrl.user_preview_response, questionID) != undefined) {
      //replace
      ctrl.user_preview_response[ctrl.findDuplicate(ctrl.user_preview_response, questionID)] = {
        questionID: questionID,
        userResponse: selectedValue
      };
    } else {
      //push
      ctrl.user_preview_response.push({
        questionID: questionID,
        userResponse: selectedValue
      });
    }

  }

  ctrl.findDuplicate = function (arr, key) {
    for (var i = 0; i < arr.length; i++) {
      if (arr[i].questionID == key) {
        return i;
      }
    }
  }

  ctrl.getCalculatedUserResult = function (formula) {
    //formula = Q1 + Q2 expression
    var arr = ctrl.user_preview_response;
    var f = formula.toString();


    if (f != '') {
      if (arr.length > 0) {
        for (var i = 0; i < arr.length; i++) {
          var q = 'Q' + arr[i].questionID;
          f = f.replace(new RegExp(q, 'g'), arr[i].userResponse);
        }

        return eval(f);

      } else {
        return 'User did not choose anything';
      }

    } else {
      return 'Formula Not Created';
    }

    // const a = 'Q1+Q1';
    // $log.log(a.replace('Q1','Q7'));


  };

  ctrl.isSelected = function (currentView, value) {
    // $log.log(currentView + '    hiihihii     ' + value);
    var arr = ctrl.user_preview_response;
    var key = currentView;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i].questionID == key && arr[i].selectedValue == value) {
        $log.log('got it');
        return true;
      }
    }
    return false;
  };

});

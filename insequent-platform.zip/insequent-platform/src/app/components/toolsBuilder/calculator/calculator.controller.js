"use strict";

angular.module("insequent").controller("CalculatorController", function ($log, $timeout, $uibModal, $window, $scope) {

  /*eslint angular/controller-as-vm: 0*/
  var ctrl = this;
  /*eslint angular/controller-as-vm: 0*/
  ctrl.isFormulatSet = false;
  ctrl.isQuestionSet = false;
  ctrl.isDisabled = false;  // flag for whether new Question can be added nor not
  ctrl.pageType = 0; // 0 : Welcome Page, 1: Other Pages, 2: Result Page

  ctrl.textBox = { 'value': '', 'text': '' } // holds the value for form builder text box

  // current question title
  ctrl.question = {};
  ctrl.question.title = null;
  ctrl.question.id = null;
  // current option of current question
  ctrl.option = {
    'caption': null,
    'value': null,
    'id': 0,
    'isEdit': false
  };
  // a background color or image belong to current question section
  ctrl.backgroundImage = null;
  ctrl.backgroundColor = '#fff'; // bt default color is white

  // list of options of current question
  ctrl.options = [];

  // holds all the questions
  ctrl.templates = [];

  //for preview
  ctrl.currentView = 0;

  //style
  ctrl.fontFamily = ['cursive', 'fantasy', 'initial', 'monospace', 'sans-serif', 'serif', 'unset'];
  ctrl.themeColor = '';
  ctrl.backgroundUrl = '';
  ctrl.themeColors = [
    {
      'c1': '#e5edf8',
      'c2': '#3a5771',
      'c3': '#2c4b60'
    },
    {
      'c1': '#eaf6f6',
      'c2': '#318f8b',
      'c3': '#2e4b4a'
    },
    {
      'c1': '#eff7e8',
      'c2': '#598234',
      'c3': '#405131'
    },
    {
      'c1': '#ffbfbf',
      'c2': '#cc3a3a',
      'c3': '#fd3d3d'
    },
    {
      'c1': '#444444',
      'c2': '#ff981e',
      'c3': '#ffb715'
    }
  ];
  ctrl.style = {
    'color': '',
    'font-family': '',
    'font-size': '',
    'font-weight': '',
    'font-style': '',
    'text-decoration': ''
  };
  ctrl.themeStyle = {
    'buttonStyle': {},
    'headingStyle': {},
    'subHeadingStyle': {},
    'backgroundStyle': {},
    'logoUrl': ''
  };

  // by default there will be a wellcome page
  ctrl.welcome = {};
  ctrl.welcome.isWelcomePage = true;
  ctrl.welcome.welcomeHeading = "";
  ctrl.welcome.headingStyle = angular.copy(ctrl.style);
  ctrl.welcome.welcomeSubheading = "";
  ctrl.welcome.subHeadingStyle = angular.copy(ctrl.style);
  ctrl.welcome.welcomeButtonText = "";
  ctrl.welcome.logoPath = ""; // not used currently
  ctrl.welcome.pageType = 0;
  ctrl.welcome.prevPtr = null;
  ctrl.welcome.thisPtr = 0;
  ctrl.welcome.nextPtr = 1;
  ctrl.templates.push(ctrl.welcome);

  // Result Pagr
  ctrl.result = {
    'heading': "",
    'headingStyle': angular.copy(ctrl.style),
    'subheading': "",
    'subHeadingStyle': angular.copy(ctrl.style),
    'buttonText': "",
    'expression': '',
    'pageType': 2,
    'prevPtr': 0,
    'thisPtr': 1,
    'nextPtr': null

  };
  ctrl.templates.push(ctrl.result);

  // for lead generation screen //
  ctrl.hasLeadScreen = false;
  ctrl.addLeadButtneText = "ADD LEAD SCREEN";
  ctrl.leadScreen = {
    'heading': "",
    'headingStyle': angular.copy(ctrl.style),
    'subheading': "",
    'subHeadingStyle': angular.copy(ctrl.style),
    'email': "",
    'phone': "",
    'name': "",
    'remarks': "",
    'isEmail': true,
    'isPhone': false,
    'isName': true,
    'isRemarks': false,
    'pageType': 3,
    'prevPtr': null,
    'thisPtr': null,
    'nextPtr': null
  };

  ctrl.addRemoveLeadScreen = function () {
    if (ctrl.hasLeadScreen) { // Remove
      ctrl.hasLeadScreen = false;
      ctrl.addLeadButtneText = "ADD LEAD SCREEN";
      ctrl.result.prevPtr = ctrl.leadScreen.prevPtr;
      ctrl.result.thisPtr = ctrl.leadScreen.thisPtr;
      ctrl.templates.splice(ctrl.templates.length - 2, 1);
    } else {  //Add
      ctrl.hasLeadScreen = true;
      ctrl.addLeadButtneText = "REMOVE LEAD SCREEN";
      ctrl.leadScreen.prevPtr = ctrl.result.prevPtr;
      ctrl.leadScreen.thisPtr = ctrl.result.thisPtr;
      ctrl.leadScreen.nextPtr = ctrl.result.thisPtr + 1;
      ctrl.result.prevPtr = ctrl.leadScreen.thisPtr;
      ctrl.result.thisPtr = ctrl.leadScreen.nextPtr;
      ctrl.templates.splice(ctrl.templates.length - 1, 0, ctrl.leadScreen);
    }
    $log.log(ctrl.templates);
  };

  // Final result
  ctrl.isInvalidExp = false;


  //store user response for preview
  ctrl.user_preview_response = [];


  // trigger a click event to display the welcome page
  $timeout(function () {
    angular.element('#welcomeBox').triggerHandler('click');
  }, 0);

  ctrl.initTemplate = function () {
    $log.log('initTemplate');
    ctrl.isFormulatSet = false;
    ctrl.IsFormulaTextError = '';
  };

  ctrl.saveTemplate = function (questionId) {
    if (ctrl.options.length === 0 || questionId) {
      return;
    }
    var temp = {};

    //temp = ctrl.templates.find(template => template.questionId === questionId);
    if (ctrl.templates.length === 2) {
      temp.prevPtr = 0;
      temp.thisPtr = 1;
      temp.nextPtr = 2;
    } else {
      if (ctrl.hasLeadScreen) {
        temp.prevPtr = ctrl.templates.length - 3;
        temp.thisPtr = ctrl.templates.length - 2;
        temp.nextPtr = ctrl.templates.length - 1;
      } else {
        temp.prevPtr = ctrl.templates.length - 2;
        temp.thisPtr = ctrl.templates.length - 1;
        temp.nextPtr = ctrl.templates.length;
      }
      ctrl.leadScreen.prevPtr = ctrl.result.prevPtr;
      ctrl.leadScreen.thisPtr = ctrl.result.thisPtr;
      ctrl.leadScreen.nextPtr = ctrl.result.thisPtr + 1;
    }
    ctrl.result.prevPtr = ctrl.templates.length - 1;
    ctrl.result.thisPtr = ctrl.templates.length;

    temp.pageType = 1;
    temp.question = angular.copy(ctrl.question);

    temp.questionTitle = angular.copy(ctrl.question);
    temp.questionStyle = angular.copy(ctrl.style);
    temp.questionOptions = angular.copy(ctrl.options);
    temp.backgroundImage = angular.copy(ctrl.backgroundImage);
    temp.backgroundColor = angular.copy(ctrl.backgroundColor);
    temp.selectedValue = '';
    temp.question.id = Math.floor(Math.random() * 2000) + 1;
    if (ctrl.hasLeadScreen) {
      ctrl.templates.splice(ctrl.templates.length - 2, 0, temp);
    } else {
      ctrl.templates.splice(ctrl.templates.length - 1, 0, temp);
    }
    ctrl.isDisabled = true;
    ctrl.question = {};
    ctrl.style = {};
    ctrl.option.caption = null;
    ctrl.option.value = null;
    ctrl.option.id = null;
    ctrl.option.isEdit = false;

    ctrl.options = [];
    ctrl.isDisabled = false;
    $log.log('=======w===========');
    $log.log(ctrl.templates);
    // $log.log(JSON.stringify(ctrl.templates));
    ctrl.addNewQuestion();
  };

  ctrl.deleteTemplate = function (questionId) {
    $log.log('questionId == ' + questionId);
    var flag = false;
    //var templatesLength = ctrl.templates.length;
    var i = 0;
    for (i = 0; i < ctrl.templates.length; i++) {
      $log.log('out' + i);
      if (ctrl.templates[i].question && ctrl.templates[i].question.id === questionId && ctrl.templates[i].pageType === 1) {
        $log.log('splice');
        // thisPtr = ctrl.templates[i].thisPtr;
        ctrl.templates.splice(i, 1);
        flag = true;
      }
      if (flag) {
        $log.log('flag');
        ctrl.templates[i].prevPtr = ctrl.templates[i].prevPtr - 1;
        ctrl.templates[i].thisPtr = ctrl.templates[i].thisPtr - 1;
        ctrl.templates[i].nextPtr ? ctrl.templates[i].nextPtr = ctrl.templates[i].nextPtr - 1 : ctrl.templates[i].nextPtr = null;
      }
    }
    ctrl.addNewQuestion();
    $log.log(ctrl.templates);
  };

  ctrl.viewTemplate = function (template) {
    if (template.isWelcomePage) {
      // for welcome page
      ctrl.pageType = 0;
      ctrl.welcomeHeading = template.welcomeHeading;
      ctrl.welcomeSubheading = template.welcomeSubheading;
      ctrl.welcomeButtonText = template.welcomeButtonText;

    } else {
      ctrl.pageType = 1;
      ctrl.options = template.questionOptions;
      ctrl.question = template.question;
      ctrl.style = template.questionStyle;
      // $log.log(template);
      ctrl.isDisabled = true;
    }
  };

  ctrl.addMoreOption = function () {
    // ctrl.option.value ? ctrl.option.value = true : ctrl.option.value = false;
    if (ctrl.option.caption === null || ctrl.option.value === null || !ctrl.question.title) {
      return;
    }
    ctrl.options.push(angular.copy(ctrl.option));
    ctrl.option.caption = null;
    ctrl.option.value = null;
    ctrl.option.isEdit = false;
  };
  ctrl.optionEditToggle = function (option) {
    option.isEdit ? option.isEdit = false : option.isEdit = true;
  }

  ctrl.optionDelete = function (index) {
    ctrl.options.splice(index, 1);
  }

  ctrl.addNewQuestion = function () {
    ctrl.question = {};
    ctrl.question = null;
    ctrl.style = {};
    ctrl.option.caption = null;
    ctrl.option.value = null;
    ctrl.option.isEdit = false;
    ctrl.options = [];
    ctrl.isDisabled = false;
    ctrl.pageType = 1;
  };

  ctrl.openResult = function () {
    ctrl.pageType = 2;
  };
  ctrl.openLead = function () {
    ctrl.pageType = 3;
  };

  ctrl.createFormula = function () {
    $log.log(ctrl.templates);
    ctrl.modalInstance = $uibModal.open({
      templateUrl: 'app/components/toolsBuilder/calculator/resultModal.html',
      size: 'lg',
      scope: $scope
    });
  }

  ctrl.closeModal = function () {
    ctrl.modalInstance.close();
  }

  ctrl.putValueAtTextBox = function (questionIndex, questionId) {
    $log.log(questionIndex);
    ctrl.textBox.text = ctrl.textBox.text + "Q" + questionIndex;
    ctrl.textBox.value = ctrl.textBox.value + "Q" + questionId;
    var name = $window.document.getElementById('exp');
    name.focus();
  }

  ctrl.applyFormula = function () {
    if (ctrl.textBox.text === null || ctrl.textBox.text === '') {
      ctrl.isInvalidExp = true;
      return;
    }
    try {
      /*eslint no-undef: 0*/
      var node = math.parse(ctrl.textBox.text);
      /*eslint no-undef: 0*/
      node.compile();
      ctrl.isInvalidExp = false;
      var temp;
      for (var i = 0; i < ctrl.templates.length; i++) {
        if (ctrl.templates[i].pageType === 2) {
          temp = ctrl.templates[i];
          ctrl.result = temp;
          ctrl.result.expression = ctrl.textBox.value;
          break;
        }
      }
      if (!temp) {
        ctrl.result.expression = ctrl.textBox.value;
        ctrl.result.pageType = 2
        ctrl.templates.push(ctrl.result);
      }
      ctrl.isFormulatSet = false;
      ctrl.IsFormulaTextError = '';
      ctrl.closeModal();
    } catch (err) {
      ctrl.isInvalidExp = true;
      $log.log(err);
    }
  }

  ctrl.previewTemplate = function () {
    ctrl.currentView = 0;
    $log.log(ctrl.templates);
    if (ctrl.templates[ctrl.templates.length - 1].expression) {
      ctrl.isFormulatSet = false;
      ctrl.IsFormulaTextError = '';
      ctrl.modalPreview = $uibModal.open({
        templateUrl: 'app/components/toolsBuilder/calculator/previewModal.html',
        size: 'lg',
        scope: $scope
      });
    }
    else {
      ctrl.isFormulatSet = true;
      ctrl.IsFormulaTextError = 'Please set the formula first !';
    }
  };
  ctrl.closePreviewModal = function () {
    ctrl.modalPreview.close();
  }

  ctrl.nextPage = function (next) {
    if (ctrl.templates[ctrl.currentView].selectedValue == '') {
      ctrl.isQuestionSet = true;
      ctrl.IsQuestionTextError = 'Please select an answer';
    }
    else {
      ctrl.currentView = next;
      ctrl.isQuestionSet = false;
      ctrl.IsQuestionTextError = '';
    }
  };

  ctrl.prevPage = function (prev) {
    ctrl.currentView = prev;
  };

  //Record user response for the preview
  ctrl.recordUserPreviewResponse = function (selectedValue) {
    ctrl.templates[ctrl.currentView].selectedValue = selectedValue;
    $log.log(ctrl.templates);

    if (ctrl.findDuplicate(ctrl.user_preview_response, ctrl.templates[ctrl.currentView].question.id) != undefined) {
      //replace
      ctrl.user_preview_response[ctrl.findDuplicate(ctrl.user_preview_response, ctrl.templates[ctrl.currentView].question.id)] = {
        questionID: ctrl.templates[ctrl.currentView].question.id,
        userResponse: selectedValue
      };
    } else {
      //push
      ctrl.user_preview_response.push({
        questionID: ctrl.templates[ctrl.currentView].question.id,
        userResponse: selectedValue
      });
    }
    // $log.log(ctrl.user_preview_response);

  }

  ctrl.findDuplicate = function (arr, key) {
    for (var i = 0; i < arr.length; i++) {
      if (arr[i].questionID == key) {
        return i;
      }
    }
  }

  ctrl.getCalculatedUserResult = function (formula) {
    //formula = Q1 + Q2 expression
    var arr = ctrl.user_preview_response;
    var f = formula.toString();
    $log.log(arr);
    $log.log(f);


    if (f != '') {
      if (arr.length > 0) {
        for (var i = 0; i < arr.length; i++) {
          var q = 'Q' + arr[i].questionID;
          f = f.replace(new RegExp(q, 'g'), arr[i].userResponse);
        }

        return eval(f);

      } else {
        return 'User did not choose anything';
      }

    } else {
      return 'Formula Not Created';
    }

  }
  ctrl.isTheme = false;
  ctrl.openTheme = function () {
    ctrl.isTheme = !ctrl.isTheme;
  };
  ctrl.color = function (thisColor) {
    $log.log(thisColor);
    ctrl.themeColor = thisColor;
  };
  ctrl.setTheme = function () {
    if (ctrl.themeColor) {
      // for (i = 0; i < ctrl.templates.length; i++) {
      //   if(){
      //   ctrl.templates[i].headingStyle['color'] = JSON.parse(ctrl.themeColor).c3;
      //   ctrl.templates[i].subHeadingStyle['color'] = JSON.parse(ctrl.themeColor).c3;
      //   }
      // }
      ctrl.makeStyle(ctrl.themeStyle.buttonStyle, 5, ctrl.themeColor.c2);
      ctrl.makeStyle(ctrl.themeStyle.headingStyle, 7, ctrl.themeColor.c3);
      ctrl.makeStyle(ctrl.themeStyle.subHeadingStyle, 7, ctrl.themeColor.c3);
      ctrl.makeStyle(ctrl.themeStyle.backgroundStyle, 5, ctrl.themeColor.c1);
    }
    ctrl.makeStyle(ctrl.themeStyle.backgroundStyle, 6, ctrl.backgroundUrl);
    $log.log(ctrl.themeStyle);
  };

  ctrl.makeStyle = function (model, operation, option) {
    // $log.log(ctrl.templates);
    switch (operation) {
      case 1://font-family
        model['font-family'] = option;
        break;
      case 2://bold
        model['font-weight'] == '' ? model['font-weight'] = 'bold' : model['font-weight'] = '';
        break;
      case 3://italy
        model['font-style'] == '' ? model['font-style'] = 'italic' : model['font-style'] = '';
        break;
      case 4://underline
        model['text-decoration'] == '' ? model['text-decoration'] = 'underline' : model['text-decoration'] = '';
        break;
      case 5://background-color
        model['background-color'] = option;
        break;
      case 6://background-image
        model['background-image'] = "url('" + option + "')";
        break;
      case 7://color
        model['color'] = option;
        break;
    }
  };

  ctrl.flag = 0;
  ctrl.openGallery = function (flag) {
    ctrl.flag = flag;
    ctrl.galleryModal = $uibModal.open({
      templateUrl: 'app/components/toolsBuilder/galleryModal.html',
      size: 'lg',
      scope: $scope
    });
  };

  ctrl.closeGallery = function () {
    ctrl.galleryModal.close();
  };

  ctrl.saveFileUrl = function (selectedFileUrl) {
    switch (ctrl.flag) {
      case 1:
        ctrl.backgroundUrl = selectedFileUrl;
        break;
      case 2:
        ctrl.themeStyle.logoUrl = selectedFileUrl;
        break;
    }
    ctrl.closeGallery();
  };

});

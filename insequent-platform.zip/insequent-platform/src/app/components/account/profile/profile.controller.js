"use strict";
/*eslint angular/di: [2,"array"]*/
angular.module("insequent").controller("ProfileController", ['$rootScope', '$scope', '$log', '$state', '$localStorage', 'Store', '$filter', '$interval', function ($rootScope, $scope, $log, $state, $localStorage, Store, $filter, $interval) {

  /*eslint angular/controller-as-vm: 0*/
  var ctrl = this;
  /*eslint angular/controller-as-vm: 0*/

  ctrl.name = '';
  ctrl.phone = '';
  ctrl.email = '';
  ctrl.isSuccess = false;
  ctrl.isError = false;
  ctrl.isPassSuccess = false;
  ctrl.isPassError = false;
  ctrl.isUpdatePassError = false;

  ctrl.user = {
    token: null,
    name: null,
    phone: null,
    file: null
  }

  ctrl.editUserPassword = {
    token: null,
    oldPassword: null,
    newPassword: null,
    confirmPassword: null
  }

  $interval(function () {
    ctrl.isSuccess = false;
    ctrl.isError = false;
    ctrl.isUpdatePassSuccess = false;
    ctrl.isUpdatePassError = false;
  }, 8000);


  ctrl.isShow = function () {
    ctrl.isSuccess = false;
    ctrl.isError = false;
  };

  $scope.$watch('ctrl.email', function (val) {
    ctrl.email = $filter('lowercase')(val);
  }, true);

  Store.getUser($localStorage.apiToken)
    .then(function (response) {
      $log.log('======User data=======');
      $log.log(response);
      ctrl.name = response.data.name;
      ctrl.phone = parseInt(response.data.phone);
      ctrl.email = response.data.email;
    }).catch(function (error) {
      $log.log(error);
    });

  ctrl.editUser = function () {
    ctrl.isSuccess = false;
    ctrl.isError = false;
    var file = $scope.myFile;
    ctrl.user.token = $localStorage.apiToken;
    ctrl.user.name = ctrl.name;
    ctrl.user.phone = ctrl.phone;
    if (file) {
      var extn = file.name.split(".").pop();
      if (extn === 'png' || extn === 'jpg' || extn === 'jpeg') {
        ctrl.user.file = file;
        Store.editUser(ctrl.user)
          .then(function (response) {
            $log.log('======Edit data=======');
            $log.log(response);
            ctrl.isSuccess = true;
          }).catch(function (error) {
            $log.log(error);
            ctrl.isError = true;
          });
      }
      else {
        ctrl.isError = true;
      }
    } else {
      Store.editUser(ctrl.user)
        .then(function (response) {
          $log.log('======Edit data=======');
          $log.log(response);
          ctrl.isSuccess = true;
        }).catch(function (error) {
          $log.log(error);
          ctrl.isError = true;
        });
    }
  };

  ctrl.editPassword = function () {
    ctrl.isUpdatePassSuccess = false;
    ctrl.updatePasswordSuccessText = '';

    if (ctrl.newPassword != ctrl.confirmPassword) {
      ctrl.isUpdatePassError = true;
      ctrl.updatePassword = 'Password does not match';
    }
    else {
      ctrl.isUpdatePassError = false;
      ctrl.updatePassword = '';

      ctrl.editUserPassword.token = $localStorage.apiToken;
      ctrl.editUserPassword.oldPassword = ctrl.oldPassword;
      ctrl.editUserPassword.newPassword = ctrl.newPassword;
      ctrl.editUserPassword.confirmPassword = ctrl.confirmPassword;

      Store.editPassword(ctrl.editUserPassword)
        .then(function (response) {
          $log.log('======Edit Password=======');
          $log.log(response);
          if (response.errors.status == 400) {
            ctrl.isUpdatePassError = true;
            //ctrl.updatePassword = 'Old password does not match';
            ctrl.updatePassword = 'Something is going wrong';
          } else {
            ctrl.isUpdatePassError = false;
            ctrl.updatePassword = '';

            ctrl.isUpdatePassSuccess = true;
            ctrl.updatePasswordSuccessText = 'Password has been changed successfully';
          }
        }).catch(function () {
          //$log.log(error);
        });
    }
  };

}]);



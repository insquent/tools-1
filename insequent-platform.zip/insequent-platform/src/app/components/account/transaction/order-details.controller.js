"use strict";

angular.module("insequent").controller("OrderDetailsController", function () {

  // eslint-disable-next-line angular/controller-as-ctrl
  // var ctrl = this;
});

"use strict";

angular.module("insequent").controller("OrderHistoryController", function () {

  // eslint-disable-next-line angular/controller-as-ctrl
  // var ctrl = this;
});

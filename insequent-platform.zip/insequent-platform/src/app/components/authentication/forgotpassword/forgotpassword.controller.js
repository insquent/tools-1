"use strict";

angular.module("insequent").controller("ForgotPasswordController", function($log, $state) {

  /*eslint angular/controller-as-vm: 0*/
  var ctrl = this;
  /*eslint angular/controller-as-vm: 0*/

  ctrl.doSubmit = function() {
    $log.log('heloo');
    $state.go('index.main');
  };

});

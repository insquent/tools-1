"use strict";

angular.module("insequent").controller("SigninController", function ($rootScope, $log, $state, $localStorage, Store) {

  /*eslint angular/controller-as-vm: 0*/
  var ctrl = this;
  /*eslint angular/controller-as-vm: 0*/

  ctrl.user = {
    email: null,
    password: null
  }

  if ($localStorage.userRegName) {
    ctrl.isSuccess = true;
    $localStorage.$reset();
  }

  if ($localStorage.apiToken) {
    $state.go('index.main');
  }

  ctrl.signin = function () {
    ctrl.isError = false;
    ctrl.isSuccess = false;
    ctrl.user.email = ctrl.email;
    ctrl.user.password = ctrl.password;
    Store.userSignIn(ctrl.user)
      .then(function (response) {
        $log.log('======Sign In=======');
        if (response.data.errors) {
          if (response.data.errors[0].status === 401) {
            ctrl.errorText = "Invalid username or password";
            ctrl.isError = true;
          } else if (response.data.errors[0].status === 403) {
            ctrl.errorText = "Please verify your email";
            ctrl.isError = true;
          }
        } else {
          ctrl.isError = false;
          $localStorage.apiToken = response.data.api_token;
          $log.log($localStorage.apiToken);
          Store.getUser($localStorage.apiToken)
            .then(function (response) {
              $log.log('======User data=======');
              $log.log(response);
              $localStorage.userName = response.data.name;
              $localStorage.profileImage = response.data.photo_url;
              $rootScope.$broadcast('name', response.data.name);
              $rootScope.$broadcast('picture', response.data.photo_url);
            }).catch(function (error) {
              $log.log(error);
            });
          $state.go('index.main');
        }
      }).catch(function (error) {
        $log.log(error);
        ctrl.errorText = "Something is going wrong";
        ctrl.isError = true;
      });
  };

});

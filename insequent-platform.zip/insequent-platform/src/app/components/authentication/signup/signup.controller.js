"use strict";

angular.module("insequent").controller("SignUpController", function ($scope, $log, $state, Store, $localStorage, $filter) {

  /*eslint angular/controller-as-vm: 0*/
  var ctrl = this;
  /*eslint angular/controller-as-vm: 0*/
  ctrl.user = {
    name: null,
    email: null,
    phone: null,
    password: null
  }
  $scope.$watch('ctrl.email', function (val) {
    ctrl.email = $filter('lowercase')(val);
  }, true);
  ctrl.signup = function () {
    ctrl.user.name = ctrl.name;
    ctrl.user.email = ctrl.email;
    ctrl.user.phone = ctrl.phone;
    ctrl.user.password = ctrl.password;
    Store.userSignUp(ctrl.user)
      .then(function (response) {
        $log.log('======Sign Up=======');
        $localStorage.userRegName = response.data.name;
        $log.log($localStorage.userRegName);
        $state.go('signin');
      }).catch(function (error) {
        //ctrl.isAnyLatest = false;
        $log.log(error);
      });
  };

});

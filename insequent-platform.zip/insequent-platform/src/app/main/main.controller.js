'use strict';

angular.module('insequent')
  .controller('MainController', function ($scope, $log, $rootScope, $localStorage, $state, Store) {

    /*eslint angular/controller-as-vm: 0*/
    var ctrl = this;
    /*eslint angular/controller-as-vm: 0*/

    $scope.$on('name', function (event, data) {
      ctrl.userName = data;
    });
    $scope.$on('picture', function (event, data) {
      $rootScope.profileImage = data
    });

    if ($localStorage.apiToken) {
      Store.getUser($localStorage.apiToken)
        .then(function (response) {
          $log.log('======User data=======');
          $log.log(response);
          ctrl.userName = response.data.name;
          $rootScope.profileImage = response.data.photo_url;
        }).catch(function (error) {
          $log.log(error);
        });
    }


    ctrl.helloText = 'Welcome to Insequent';
    ctrl.descriptionText = 'A complete marketing solution';

    /*eslint angular/on-watch: 0*/
    $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams) {
      ctrl.pageTitle = toParams.pageTitle;
      ctrl.path = toParams.path;
    });

    $rootScope.logout = function () {
      $localStorage.$reset();
      $state.go('signin');
    }
    /*eslint angular/on-watch: 0*/

  });

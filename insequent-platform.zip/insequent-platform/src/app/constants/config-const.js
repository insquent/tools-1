'use strict';
angular.module('insequent').constant('Config', {
  // gulp environment: injects environment vars
  ENV: {
    /*inject-env*/
    'SERVER_URL': 'http://localhost/insequent/public/',
    'SOME_OTHER_URL': '',
    "AUTH_APPEND": "Bearer ",
    'USER': {
      'AUTH_TOKEN': '',
      'USER_ID': '',
      'UNAME': '',
      'UEMAIL': ''
    }
    /*endinject*/
  },

  // gulp build-vars: injects build vars
  BUILD: {
    /*inject-build*/
    /*endinject*/
  }
});

'use strict';
angular.module('insequent')
  .factory('Store', function (
    $log,
    $http,
    Config
  ) {

    $log.log('Hello from your Service: Api Store Fact in module store');

    return {
      userSignUp: function (user) {
        var param = {
          'name': user.name,
          'email': user.email,
          'phone': user.phone,
          'password': user.password
        };
        return $http.post(Config.ENV.SERVER_URL + 'api/register', param, {
          transformResponse: function (response) {
            var dataParse = angular.fromJson(response).data;
            return dataParse;
          }
        });
      },
      userSignIn: function (user) {
        var param = {
          'email': user.email,
          'password': user.password
        };
        return $http.post(Config.ENV.SERVER_URL + 'api/login', param, {
          transformResponse: function (response) {
            if (angular.fromJson(response).errors) {
              $log.log(angular.fromJson(response));
              var errorParse = angular.fromJson(response);
              return errorParse;
            } else {
              var dataParse = angular.fromJson(response).data;
              return dataParse;
            }
          }
        });
      },
      getUser: function (jwtToken) {
        var token = Config.ENV.AUTH_APPEND + jwtToken;
        return $http.get(Config.ENV.SERVER_URL + 'api/getuser', {
          headers: {
            'Authorization': token
          }
        }).then(function (response) {
          var dataParse = angular.fromJson(response).data;
          return dataParse;
        });
      },
      editUser: function (user) {
        var token = Config.ENV.AUTH_APPEND + user.token;
        if (user.file !== null) {
          var fdWithFile = new FormData();
          fdWithFile.append('image', user.file);
          fdWithFile.append('name', user.name);
          fdWithFile.append('phone', user.phone);
          $log.log(fdWithFile);
          return $http.post(Config.ENV.SERVER_URL + 'api/update/profile', fdWithFile, {
            headers: {
              'Authorization': token,
              'enctype': 'multipart/form-data',
              'Content-Type': undefined
            }
          }).then(function (response) {
            var dataParse = angular.fromJson(response).data;
            return dataParse;
          });
        } else {
          $log.log(user.name);
          var fdWithoutFile = new FormData();
          fdWithoutFile.append('name', user.name);
          fdWithoutFile.append('phone', user.phone);
          $log.log(fdWithoutFile);
          return $http.post(Config.ENV.SERVER_URL + 'api/update/profile', fdWithoutFile, {
            headers: {
              'Authorization': token,
              'enctype': 'multipart/form-data',
              'Content-Type': undefined
            }
          }).then(function (response) {
            var dataParse = angular.fromJson(response).data;
            return dataParse;
          });
        }
      },
      editPassword: function (editUserPassword) {
        var token = Config.ENV.AUTH_APPEND + editUserPassword.token;
        var param = {
          'password': editUserPassword.oldPassword,
          'new_password': editUserPassword.newPassword,
          'new_password_confirmation': editUserPassword.confirmPassword
        };
        return $http.post(Config.ENV.SERVER_URL + 'api/update/password', param, {
          headers: {
            'Authorization': token
          }
        }).then(function (response) {
          var dataParse = angular.fromJson(response).data;
          return dataParse;
        });
      },
      mediaUpload: function (jwtToken, file, type) {
        var token = Config.ENV.AUTH_APPEND + jwtToken;
        var fd = new FormData();
        if (type === 'file') {
          fd.append('file', file);
          fd.append('type', 'file');
        } else if (type === 'video') {
          fd.append('file', file);
          fd.append('type', 'video');
        } else {
          fd.append('file', file);
          fd.append('type', 'image');
        }
        return $http.post(Config.ENV.SERVER_URL + 'api/media/storage', fd, {
          headers: {
            'Authorization': token,
            'enctype': 'multipart/form-data',
            'Content-Type': undefined
          }
        }).then(function (response) {
          var dataParse = angular.fromJson(response).data;
          return dataParse;
        });
      },
      getMedia: function (jwtToken) {
        var token = Config.ENV.AUTH_APPEND + jwtToken;
        return $http.get(Config.ENV.SERVER_URL + 'api/media/files', {
          headers: {
            'Authorization': token
          }
        }).then(function (response) {
          var dataParse = angular.fromJson(response).data;
          return dataParse;
        });
      },
      fileCount: function (jwtToken) {
        var token = Config.ENV.AUTH_APPEND + jwtToken;
        return $http.get(Config.ENV.SERVER_URL + 'api/media/counts/file', {
          headers: {
            'Authorization': token
          }
        }).then(function (response) {
          var dataParse = angular.fromJson(response).data;
          return dataParse;
        });
      },
      imageCount: function (jwtToken) {
        var token = Config.ENV.AUTH_APPEND + jwtToken;
        return $http.get(Config.ENV.SERVER_URL + 'api/media/counts/image', {
          headers: {
            'Authorization': token
          }
        }).then(function (response) {
          var dataParse = angular.fromJson(response).data;
          return dataParse;
        });
      },
      videoCount: function (jwtToken) {
        var token = Config.ENV.AUTH_APPEND + jwtToken;
        return $http.get(Config.ENV.SERVER_URL + 'api/media/counts/video', {
          headers: {
            'Authorization': token
          }
        }).then(function (response) {
          var dataParse = angular.fromJson(response).data;
          return dataParse;
        });
      },
      deleteMedia: function (jwtToken, id) {
        var token = Config.ENV.AUTH_APPEND + jwtToken;
        return $http.delete(Config.ENV.SERVER_URL + 'api/media/delete/' + id, {
          headers: {
            'Authorization': token
          }
        }).then(function (response) {
          var dataParse = angular.fromJson(response).data;
          return dataParse;
        });
      }
    };
  });

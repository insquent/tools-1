(function () {
  'use strict';

  angular
    .module('insequent', ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize', 'ngMessages', 'ngAria', 'ngResource', 'ui.router', 'ui.bootstrap', 'colorpicker.module', 'textAngular', 'ngStorage','com.2fdevs.videogular','com.2fdevs.videogular.plugins.controls']);

})();